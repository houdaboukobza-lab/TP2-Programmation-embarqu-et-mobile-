Question 1
Quelle méthode de constructeur utilisez-vous pour créer une intention implicite de lancer une application de caméra :
#new Intent() 

Question 3
Quelle action Intention utilisez-vous pour prendre une photo avec une application appareil photo : 
#Intent takePicture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
